package days10;

public class Ex09 {
	/*
	 * 1. 1차원,2차원,3차원 배열(다차원 배열)
	 * 2. 정렬(SORT)
	 * 3. 검색(SEARCH)
	 * 4. 다차원 활용예제
	 * 
	 * (클래스 5장,6장 읽기)
	 */
	public static void main(String[] args) {
		//int[]m =new int [30]   0~9 임의의 정수
		//0-3개 , 1-0개 , 9-4개 ...
		
	}//main
}//class
