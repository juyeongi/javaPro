package days14;
//days14.MyApp
//단독으로 사용될 때의 this : 매개변수
public class Ex06 {
	public static void main(String[] args) {
		//객체생성
		new MyApp();
		System.out.println("Ex06 end");
	}
}
