package days14;

public class Ex09 {
	
	//static main () 메서드
	//객체생성없이 메서드를 바로 실행하기 위해 static 사용
	public static void main(String[] args) {
		
		//클래스명.static 메서드명 ();
		// Ex09.sum(1,2);
		sum(1,2);
		
	}//main

	public static int sum(int a, int b) {
		return a+b;
		
	}
}//class
