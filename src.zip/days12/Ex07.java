package days12;

public class Ex07 {
	//객체지향적 프로그래밍, 클래스 
	public static void main(String[] args) {
		//1. 객체지향적 프로그래밍
		// Object Oriented Programming [OOP]
		// - 프로그램을 개발(구현)하는 방법(기법)
		// - 객체 + 객체 + 객체 + 객체 ... 
		// 예) 
		
		
	}//main
}//class
