package days12;

public class Ex06 {
		
	public static void main(String[] args) {
		
		for (int i = 0; i < args.length; i++) {
			System.out.printf("args[%d]=%s\n",i,args[i]);
		} //for
		
		//p.107참조변수
		
		int i =100; //변수
		int [] m = null;  //변수, 참조변수 , 배열명 : 주소값을 갖고있는 변수 
		                // null : 참조타입이 참조할 값이 없음
		
		//String name = null;
		//String name = "";
	}//main

}//class
