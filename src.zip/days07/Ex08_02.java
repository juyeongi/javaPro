package days07;

import java.util.Iterator;

import util.Draw2D;

public class Ex08_02 {
	public static void main(String[] args) {
		
		
		Draw2D.drawLine();
		System.out.println("부서명 : 사원명");
		Draw2D.drawLine(30);
		System.out.println("영업부 : 김사원");
		System.out.println("생산부 : 이사원");
		System.out.println("개발부 : 박사원");
		System.out.println("기획부 : 오사원");
		//Draw2D.drawLine(30, =);
		
		
	}//main
	//***함수선언 main함수 밖, class 안
	//1) 기능 : 선긋기 drawLine
	//2) 매개변수 : x
	//3) 리턴값 (리턴 자료형) : x void
	
	//중복함수 overloading : 매개변수의 갯수, 타입이 다르면 같은명의 함수를 만들 수 있음
	
		 
		 
		 
		

}//class
