package days07;

public class Ex11 {
	public static void main(String[] args) {
		int x=10;
		int y=20;
		System.out.printf("x=%d,y=%d\n",x, y);
		
		//두 기억공간 값 바꾸기
		/*
		int temp =x;
		x=y;
		y=temp;
		*/
		//함수만들기 
		

		System.out.printf("> x=%d, y=%d", x,y);
		
	}//main

}//class
