package days07;

import util.Draw2D;

public class Ex09 {
	public static void main(String[] args) {
		
	}//main
	/*
	Draw2D.drawLine();
	System.out.println("메서드 설명");
	Draw2D.drawLine();
	*/
}//class
