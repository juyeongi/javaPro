package days11;

import java.util.Arrays;

public class Ex05_02 {
	public static void main(String[] args) {
		int [] m = {3,5,2,4,1};
		System.out.println(Arrays.toString(m));
		
		Arrays.sort(m);
		System.out.println(Arrays.toString(m));
		
	}//main
}//class
