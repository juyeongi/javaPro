package days16;

import java.util.List;

public interface IDBCom {
	List select ();
	int insert();
	int update();
	int delete();
	
}
