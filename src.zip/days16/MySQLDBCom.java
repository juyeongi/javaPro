package days16;

import java.util.List;

public class MySQLDBCom implements IDBCom{

	@Override
	public List select() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
