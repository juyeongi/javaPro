package days16;

public class Ex07 {
	
		//	[인터페이스 (interface)]
	public static void main(String[] args) {
		/*
		 * 1.자바의 자료형
		 * 		기본형 9가지
		 * 		참조형 : 배열, 클래스(String), 인터페이스
		 *	2. 변수선언
		 *  	인터페이스 변수명(객체);
		 *  	클래스 객체;
		 *  	배열 [] 배열명;
		 *	3. 일종의 추상클래스 형식 
		 * 4. 필드 선언x
		 * 		일반 메서드 선언x
		 * 		->상수 , 추상메서드 선언
		 * 					+
		 * 		JDK1.8 1) static 메서드
		 * 	               2) default 메서드
		 * 5. 인터페이스끼리 상속 가능 (extends)
		 * 6. 다중상속 가능
		 * 7. 인터페이스 구현시 implement키워드를 사용해서 클래스선언
		 * 8. 인터페이스 안의 필드(상수)
		 * 		public static final 키워드 + 필드
		 * 		public abstract 	 키워드 + 추상메서드
		 */
	}//main
}//class
