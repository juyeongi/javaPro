package days16;

public interface Engine {

	public abstract void moreFuel(int fuel);
	void lessFuel(int fuel); 
	void stop();
}
