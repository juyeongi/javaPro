package days16;

public class Ex05 {
	public static void main(String[] args) {
		//this : 클래스 자기 자신의 주소값을 갖는 참조변수
		//super : 부모클래스의 주소값을 갖는 참조변수
		//			(=자식클래스에서 부모클래스의 멤버를 참조하는 참조변수)
		/*
		 * 		ex) Regular > SalesMan
		 * 		super.getPay () + this.shles*this.comm;
		 * 		생성자 (); -디폴트생성자 선언됨
		 * 			super(name~pay);
		 */
	}//main
}//class
