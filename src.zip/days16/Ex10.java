package days16;

public class Ex10 {
	public static void main(String[] args) {
		// DB서버 구축	: CRUD (쓰기, 읽기, 수정, 삭제)
		// DBMS	:	MySQL, Oracle, MS SQL ..
		
		
	}// main
}//class
