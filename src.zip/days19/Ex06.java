package days19;

public class Ex06 {
	public static void main(String[] args) {
		//WrapperClass(포장된 클래스) 
		//기본자료형 8가지 > 래퍼클래스
		System.out.println(Integer.MAX_VALUE);
		/*
		 * boolean > Boolean
		 * char > Character
		 * (Number클래스의 서브클래스) +BigInteger > long(8byte, -900경~900경)
		 * 										  +BigDecimal > double
		 * byte > Byte
		 * short > Short
		 * int > Integer
		 * long > Long
		 * float > Float
		 * double > Double
		 */
		
	}//main
}//class
