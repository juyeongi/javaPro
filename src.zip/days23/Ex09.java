package days23;

import java.util.TreeMap;
import java.util.TreeSet;

public class Ex09 {
	public static void main(String[] args) {
//		TreeMap<K, V>
//			  Map(key+value)
//		검색, 범위검색, 정렬 성능이 빠름
//		TreeSet	이진 트리구조 
//		Sorted+Map 정렬되는 맵
	}//main
}//class
