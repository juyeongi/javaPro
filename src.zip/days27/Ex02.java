package days27;

public class Ex02 {

}
