package days24;

public class Ex06 {
	public static void main(String[] args) {
		//[익명 (==무명 Anonymous)클래스] 
		//1. 클래스이름 x
		//2. 사용형식 
		//		부모타입	객체명 	= new 부모타입(매개변수){
		//			@Overide 재정의함수 구현		
		//			}
		//		부모타입 ==클래스, 인터페이스 
		//3. 자식클래스가 재사용하지않고 오로지 해당 필드의 초기값으로만 사용할 경우일 때
		//days22.Ex13
		//4. 부모타입으로 필드나 변수를 선언하고, 자식객체를 초기값으로 대입할 경우
		//선언과 동시에 생성해서 사용 
		
		
		//2)객체 생성 후 필드메서드 사용
		
//		Sample s = new Sample();
//		System.out.println(s.toString());
		
	}//m
}//c

//1)클래스선언
//class Sample{}