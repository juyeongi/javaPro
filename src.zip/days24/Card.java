package days24;

public enum Card {
	CLOVER,	//0	순서 ordinal()
	HEART,		//1
	DIAMOND,		//2
	SPADE		//3

}
/*
class Card{
	pulbic static final int CLOVER = 0;
	pulbic static final int HEART =1;
	pulbic static final int DIAMOND =2;
	pulbic static final int SPADE =3;
}
*/