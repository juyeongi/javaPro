package days17;

public class Ex01 {
		//unchecked 예외  days16.Ex15
		//checked 예외	days16.Ex15_02
		//사용자정의 예외 days16.Ex15_03   //ScoreOutOfBoundException
	public static void main(String[] args) {


	}

}
