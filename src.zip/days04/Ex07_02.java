package days04;

import java.util.Iterator;

public class Ex07_02 {
	public static void main(String[] args) {
		//if [명령라인 1줄일 때] {}생략 가능  // 다음에 걸리는 문이 생략한 if문에 걸리지 않게 해야함
		//if (condition) System.out.prinln("1줄");
		
		//if (condition) System.out.prinln("1줄");
	    //else System.out.println("1줄);
		
		//for (int i = 0; i < args.length; i++) System.out.println("1줄");
		//for (int i = 0; i < args.length; i++) System.out.println("1줄");
		
			
	}

}
