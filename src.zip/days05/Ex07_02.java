package days05;

public class Ex07_02 {
	public static void main(String[] args) {
		
		int i=10;
		while (i<2) {
			
		}//while
		
		//조건 상관없이 최소 1번 실행시킬 때
		do {
			System.out.println("B");
			
		}while(i<2);
			
		
	}//main

}//class
