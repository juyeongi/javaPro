package days13;

public class Ex10_02 {
	public static void main(String[] args) {
		//메서드의 리턴자료형이 참조형
	}
	
}
