package days01;

public class Ex02 {

	//main Ctrl +Space + Enter (자동완성)
	public static void main(String[] args) {
		//본인 이름을 콘솔창에 출력하는 코딩
		//모니터,프린터기 (표준 출력장치)
		//키보드 (표준 입력장치)
		//java.lang.System 클래스 (= java.lang.System.out.prinln("이주영") )
		//System.in 표준입력
		//System.out 표준출력 + println() 일/기능 함수 =매서드
		System.out.println("이주영");
		
		
	}//main

}//class
