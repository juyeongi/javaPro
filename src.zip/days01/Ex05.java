package days01;

public class Ex05 {
	
	
	public static void main(String[] args) {
		
		//+덧셈연산자
		System.out.println(  3+5  );  //8
		
		//2)+문자연결연산자
		String name = "이주영";
	
		System.out.println(  "이름 :" + "이주영");  //"이름 :이주영"
		
		
		//3) +문자열연결연산자
		//"문자열" + 정수
		//정수 + "문자열"
		int age = 20;
			
		System.out.println(  "나이 : " + age );  //"이름 : 20"
		
		System.out.println("이름은" + name + "이고, 나이는 " + age + "살입니다.");
		//이름은이주영이고, 나이는 20살입니다.
		
		
		
	}//main

}//class
