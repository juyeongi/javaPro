package days01;

//import days13.Tv;

public class Ex06_Tvtest {
	public static void main(String[] args) {
		//[public] Tv클래스를 패키지 외부에서 참조 확인
		//days13.Tv
		
		//Tv cannot be resolved to a type
		// default Tv 클래스를 패키지 외부에서 상속/참조 x
		/*
		Tv tv1 =new Tv();
		System.out.println(tv1.power);
		*/
	}
}
