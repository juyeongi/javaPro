package days01;

import days13.Time;

public class Ex07_Timetest {
		//days 13.Time + days01. Ex07_Timetest
		// 패키지 외부
	Time t = new Time();
	//t.hour = 1; // public : 패키지 내,외부 접근가능
	// t.second   // protected 패키지 내부 x, 상속관계 x
	// t.minute  // default x
	// t milisecond   // private x
	
}
