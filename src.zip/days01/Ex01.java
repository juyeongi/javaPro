package days01;

public class Ex01{

	
	public static void main(String[] args) {
		
		String name;
		name = "이주영";
		name = "김성준";
		name = "이상문";
		
	
		//이클립스에서 자주 사용하는 단축키 정리
		//단축키 목록 Ctrl +Shift + L 
		//실행  Ctrl +F11
		//자동완성  Ctrl + Space
		//들여쓰기 Ctrl + A (전체선택) , Ctrl + I
		//단일행 주석처리,해제 Ctrl +/
		
		System.out.println("이주영");
		System.out.println("김성준");
		System.out.println("이상문");
	}//main  프로그램 종료

}//class