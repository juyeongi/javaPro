package days02;

public class Ex10_02 {
	
	public static void main(String[] args) {
		String n = "10";
				
		int i = Integer.parseInt(n);
		long l = Long.parseLong(n);
		short s = Short.parseShort(n);
		byte b = Byte.parseByte(n);

		
	}//main

}//class
