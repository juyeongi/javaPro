package days02;

public class Ex03 {

	
	
	public static void main(String[] args) {
		
		
		// ***지역변수( Loacal Varialble )*** 시험1)
		
		//string %s, int %d
		//한 문자를 저장하는 자료형: char(캐릭터) %c
		//자바에서 문자를 나타낼 때는 ' ' 홑따움표 *문자열은 " "
		//char grade = 'A';
		//System.out.printf("등급 : '%c;", grade);
		
		//코드영역(블럭)
		//( ) / {} 영역(범위) 연산자 클래스 (class, main 등에 사용)
		{  //영역 설정
	
			char grade = 'A'; // 지역변수( Loacal Varialble )
			System.out.printf("등급 : '%c;", grade);
			
			
		}
		//grade 변수를 선언x 인식x
		//char grade = 'A'; // 지역변수( Loacal Varialble )
		//System.out.printf("등급 : '%c;", grade);
		
	}//main


}//class
