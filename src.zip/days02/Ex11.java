package days02;

public class Ex11 {
	
	public static void main(String[] args) {
		//(2) 논리형 - boolean(1) ( true, false. 제어문의 조건으로 사용 )
		// 성별 : 남자(true), 여자(false)
		boolean gender; //boolean :%b , 참/거짓값만 가짐
		
		gender = true;
		System.out.printf(">성별 : %b\n", gender);
				
		
		
		
	
	}

}
