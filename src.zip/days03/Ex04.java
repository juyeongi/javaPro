package days03;

public class Ex04 {
	
	public static void main(String[] args) {
		int n = 10;
		
		System.out.printf("%s\n", Integer.toString(n, 2)); // 2진법으로 변환
		System.out.printf("%s\n", Integer.toBinaryString(n));
	
	
	}//main
	
}//class
