package days03;

public class Ex05_07 {
	
	//**전위형 /후위형 증감연산자

	public static void main(String[] args) {
		
		int x =10;
		
		//int y =++x; //전위형 x=11, y=11
		//int y = x--; //후위형 x=11, y=10
		
		// 단독 사용될 때는 전 /후위형 같은 결과가 나옴
		// x++;
		//++x;
		//System.out.printf("> x=%d, y=%d\n", x, y); 
		

	}

}
