package days03;

public class Ex05_03 {

	//***비교연산자
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//비교연산자의 결과값은 true/false (boolean)
		//instaceof 비교연산자//
		
		System.out.println(10>3); //true
		System.out.println(10<3); //false
		// <,>크다,작다가 먼저 표기 
		System.out.println(10>=3); //true
		System.out.println(10<=3); //false
		//같다(==) 다르다(!=)
		System.out.println(10==3); //false 
		System.out.println(10!=3); //true
		

	}//main

}//class
