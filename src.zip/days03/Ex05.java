package days03;

public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*용어정리
		 * 1.연산자(operator)
		 *    ㄱ. 정의 : 연산을 수행하는 기호
		 *    + - *; / [] () 등등
		 * 2.피연산자(operand)
		 *    ㄱ. 정의 : 연산자의 처리(작업) 대상
		 *    ㄴ. 피연산자의 갯수에 따라서 연산자를 구분
		 *        1개 : 단항연산자  ***가장 우선순위가 높은 연산자 (먼저 연산됨)
		 *        2개 : 이항연산자 (덧셈)
		 *        2개 : 삼항연산자
		 * 3.식(수식)(expression)
		 *    ㄱ. 정의: 연산자와 피연산자를 조합하여 표현한 것(ex) 3+4 , !4,  4>3 
		 * 4. 연산자의 종류(기능에 따라)
		 *     ㄱ. 산술연산자 : + - * / Ex05_02
		 *     ㄴ. 비교연산자 : > < >= =< == !=  Ex05_03
		 *     ㄷ. 논리연산자 : true/false (boolean)
		 *     ㄹ. 대입연산자 :
		 *     ㅁ. 기타
		 */
		
		
	}//main

}//class
