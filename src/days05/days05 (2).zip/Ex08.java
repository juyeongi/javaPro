package days05;

public class Ex08 {
	public static void main(String[] args) {
		// https://programmers.co.kr/


		
		
	}//main

}//class
