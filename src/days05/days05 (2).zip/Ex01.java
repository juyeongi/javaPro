package days05;

import java.util.Iterator;

public class Ex01 {

	public static void main(String[] args) {
		
		/*System.out.println();
		System.out.println();
		if 조건식 return;
		  참이면 메인함수 빠져나감

		System.out.println();
		System.out.println();
		*/
		
		//10+9+...+2+1=55
		/*
		int sum=0;
		for (int i = 10; i >=1; i--) {
			System.out.printf("%d+", i);
			sum +=i;
			
			
		} //for
		*/
		
		/*
		for (int i = 0; i < args.length; i++) {
			////%[flags][width]conversion
			
			System.out.printf("%02d - 헬로우 월드\n", i);
			
		} //for
		*/
		//순서도 작성
		int com, user; //가위(1)
		// com-1-3 난수 임의의 수  0.0- <=double Math.random()
		// user scanner. nextInt();
		
		// 판단 user - com 
		//switch
		
		
		
		
		
		
	}//main

}//class
