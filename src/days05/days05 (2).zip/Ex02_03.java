package days05;

public class Ex02_03 {
	public static void main(String[] args) {
		
		String name ="TOTO";
		char[] nameArr = name. toCharArray (); // 1. for문사용한것과 동일한 식
		System.out.println(nameArr[0]);
		
		
		
		/* 1. 직접 배열 선언 후 for문 사용해서 처리
		String name ="TOTO";
		// String -> char[] 변환 -> char배열[0]
		char[] nameArr = nes char [name.length()];
		for (int i = 0; i < nameArr.length; i++) {
			nameArr[i] = name.charAt(i);
			[T][O][T][O]
		} //for
		// nameArr[0]
		 */
	}

}
