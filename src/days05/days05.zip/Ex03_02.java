package days05;

/**
 * @author kenik
 * @date 2023. 7. 19. - 오전 11:26:58
 * @subject
 * @content
 */
public class Ex03_02 {

	public static void main(String[] args) {
		/*
		for (int i = 'ㅏ'; i <='ㅣ' ; i++) {  
			   System.out.printf("%d-[%c]", i,  (char)i); 
		} // for
		*/
		/*
		for (int i = 'ㄱ'; i <='ㅎ' ; i++) {  
		   System.out.printf("%d-[%c]", i,  (char)i); 
		} // for
		*/
		 
		
		/* 
		for (int i = '가'; i <='힣' ; i++) { ;
			 			
			System.out.printf("%d-[%c]", i,  (char)i);
			
		} // for
		*/

	} // main

} // class






