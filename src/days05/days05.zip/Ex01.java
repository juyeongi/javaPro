package days05;

/**
 * @author kenik
 * @date 2023. 7. 19. - 오전 7:50:56
 * @subject 제어문
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		
		// 복습문제 9:50 까지 제출.
		/*
		System.out.println("a");
		System.out.println("b");
		if( 조건식 ) return ; 
		// 조건식 참이면 main 함수를 빠져나가라.
		System.out.println("c");
		*/
		
		// 10+9+8+...+2+1=55
		/*
		for (int i = 10; i >= 1; i--) {
			System.out.println(i);
		} // for
		*/
		
		/*
		for (int i = 1; i <= 10; i++) {
			//    %[flags][width]conversion
			System.out.printf("%02d - 헬로우 월드\n", i);
		} // for
		*/
		
		// [순서도 작성]
		// int com, user; // 가위(1).2.3
		// com  = 1~3 난수(임의의수)     0.0 <= double Math.random() < 1.0
		// user =  scanner.nextInt();
		
		// 판단  user-com       0(무승부)  2,-1(사용자 승리 ) ..
		// switch
		
		// 사용자 승리, 무승부 출력.		

	} // main

} // class







